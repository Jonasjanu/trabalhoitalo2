package com.example.cadastroestudante;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        //Cria um segurador
        Handler handler = new Handler();
        //Chama o metodo de thread ou tempo
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //chama a tela principal por meio do intent
                startActivity(new Intent(
                        SplashActivity.this,
                        prova.class));
                //finaliza a execução
                finish();
            } // adiciona o tempo de espera
        }, 4000);
    }


    /**Passo a passo para a Splash actvity
     * Crie uma segunda activity vazia chamada splashActivity
     * Copie uma imagem de plano de fundo para pasta drawable/
     * Na aba de texto da activity insira o seguinte codigo antes do > da tag
     * "android:background="@drawable/IFCE_logo"
     * Altere o arquivo values/styles.xml de:
     *  parent="Theme.AppCompat.Light.DarkActionBar"
     * para: parent="Theme.AppCompat.Light.NoctionBar"
     * adicione um progressBar na tela splash
     * Na classe java do splash adicione o seguinte código:
     * Handler handler = new Handler();
     *         handler.postDelayed(new Runnable() {
     *             @Override
     *             public void run() {
     *                 startActivity(new Intent(
     *                 SplashActivity.this,
     *                 MainActivity.class));
     *                 finish();
     *             }
     *         }, 4000);
* No arquivo AndroidManifest.xml mude o trecho
* de código da tag main para a tag do splash
* <intent-filter>
*   <action android:name="android.intent.action.MAIN" />
*   <category android:name="android.intent.category.
*   LAUNCHER" />
* </intent-filter>
     * */
}

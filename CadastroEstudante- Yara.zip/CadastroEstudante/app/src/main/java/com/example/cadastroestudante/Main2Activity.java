package com.example.cadastroestudante;
//Italo Arruda

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        String nome = intent.getStringExtra(MainActivity.EXTRA_TEXT);
        double tel = intent.getIntExtra(MainActivity.EXTRA_NUMBER, 00000000);
        String email = intent.getStringExtra(MainActivity.EXTRA_TEXT2);
        String end = intent.getStringExtra(MainActivity.EXTRA_TEXT3);
        String cidade = intent.getStringExtra(MainActivity.EXTRA_TEXT4);
        String estado = intent.getStringExtra(MainActivity.EXTRA_TEXT5);

        TextView nome2 = findViewById(R.id.nome);
        TextView tel2 = findViewById(R.id.textView2);
        TextView email2 = findViewById(R.id.textView4);
        TextView end2 = findViewById(R.id.textView5);
        TextView cidade2 = findViewById(R.id.textView121);
        TextView estado2 = findViewById(R.id.textView19);

        nome2.setText(nome);
        tel2.setText("" + tel);
        email2.setText(null);
        end2.setText(end);
        cidade2.setText(null);
        estado2.setText(estado);

        btn = findViewById(R.id.button3);
        btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                voltarProva();
            }

        });

    }

    public void voltarProva() {
        Intent intent = new Intent(this, prova.class);
        startActivity(intent);
    }




}

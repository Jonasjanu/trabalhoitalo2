package com.example.cadastroestudante;
//Italo Arruda
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btn;
    private Button btn2;
    public static final String EXTRA_TEXT = "com.example.link.EXTRA_TEXT";
    public static final String EXTRA_NUMBER = "com.example.link.EXTRA_NUMBER";
    public static final String EXTRA_TEXT2 = "com.example.link.EXTRA_TEXT2";
    public static final String EXTRA_TEXT3 = "com.example.link.EXTRA_TEXT3";
    public static final String EXTRA_TEXT4 = "com.example.link.EXTRA_TEXT4";
    public static final String EXTRA_TEXT5 = "com.example.link.EXTRA_TEXT5";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.cadastrarBtn);
        btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                openActivity2();
            }

        });

        btn = findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                voltarProva();
            }

        });

    }

    public void voltarProva(){
        Intent intent = new Intent(this, prova.class);
        startActivity(intent);
    }

    public void openActivity2(){

        EditText nome = findViewById(R.id.nameText);
        EditText tel = findViewById(R.id.telText);
        EditText email = findViewById(R.id.emailText);
        EditText end = findViewById(R.id.enderecoText);
        EditText cidade = findViewById(R.id.cityText);
        EditText estado = findViewById(R.id.estadoText);

        String nome2 = nome.getText().toString();
        int tel2 = Integer.parseInt(tel.getText().toString());
        String email2 = email.getText().toString();
        String end2 = end.getText().toString();
        String cidade2 = cidade.getText().toString();
        String estado2 = estado.getText().toString();

        Intent intent = new Intent(this, Main2Activity.class);

        intent.putExtra(EXTRA_TEXT, nome2);
        intent.putExtra(EXTRA_NUMBER, tel2);
        intent.putExtra(EXTRA_TEXT2, email2);
        intent.putExtra(EXTRA_TEXT3, end2);
        intent.putExtra(EXTRA_TEXT4, cidade2);
        intent.putExtra(EXTRA_TEXT5, estado2);

        /*Toast.makeText(MainActivity.this,
         "Cadastrado com sucesso",
         Toast.LENGTH_SHORT).show(); */


    }

}

package com.example.cadastroestudante;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class prova extends AppCompatActivity {
    private Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prova);

        btn2 = findViewById(R.id.button);
        btn2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                telaMain();
            }

        });


    }

    public void telaMain(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
